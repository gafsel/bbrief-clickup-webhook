import business.webhook
import json

def lambda_handler(event, context):
    business.create_event(json.loads(event["body"]))

    return {
        'statusCode': 200
    }
